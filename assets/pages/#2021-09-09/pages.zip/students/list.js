$('[data-label="return_student"]').click(function(){
	window.location.href = base_url+'students/list';
});